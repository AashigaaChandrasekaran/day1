#include<stdio.h>
int main(){
    int num,rem=0,sum=0;
    scanf("%d",&num);
    int n=num;
    while(num>0){
        rem=num%10;
        sum=sum+rem;
        num=num/10;
    }
    if(n%sum==0) {
        printf("%d IS HARSHAD NUMBER",n);
    }
    else{
        printf("%d IS NOT A HARSHAD NUMBER",n);
    }
}