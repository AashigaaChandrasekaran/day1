#include <stdio.h>
#include <string.h>
int main() {
    char s[] = "123456";
    int len=strlen(s);
    int number[len],i;
    for(i= 0; i < sizeof(s)/sizeof(s[0]); i++)
     {
       number[i] = (s[i] - '0');
    }   
    for(i = 0; i < sizeof(number)/sizeof(number[0]); i++) {
       printf("%d ", number[i]/2);
    }
    return 0;
}